<?php
require_once 'includes/check_session.inc.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Time</title>
  <link rel="stylesheet" href="assets/clock.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;700&display=swap" rel="stylesheet">
  <style>
    body, html {
      height: 100%;
      margin: 0;
      display: flex;
      justify-content: center;
      align-items: center;
    }
  </style>
</head>
<body>
  <!-- partial:index.partial.html -->
  <h1 class="page-header"> Clock </h1>
  <div class="clock">
    <div class="hour"></div>
    <div class="min"></div>
    <div class="sec"></div>
  </div>
  <script src="clock.js"></script>
  <script src="script.js"></script>
</body>
</html>

